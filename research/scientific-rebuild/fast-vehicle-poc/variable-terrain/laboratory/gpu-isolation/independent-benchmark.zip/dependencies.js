// The portable build copies these same modules beside the entry point.
export const sources = {
  'three-gl': './vendor-r180/three.module.js',
  'three-gpu': './vendor-r180/three.webgpu.js',
  'three-new': './vendor-r187/three.webgpu.js',
};
export const laboratoryAvailable = false;
