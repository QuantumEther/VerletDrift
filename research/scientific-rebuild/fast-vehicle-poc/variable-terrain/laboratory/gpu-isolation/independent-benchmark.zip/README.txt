Extract this ZIP. In the extracted directory run python3 -m http.server 8792 --bind 127.0.0.1
Open http://127.0.0.1:8792/gpu-isolation/ in Chrome. Enter the simulator buffer dimensions, Run Benchmark, then Export JSON.
